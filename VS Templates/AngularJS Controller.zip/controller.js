(function () {
    'use strict';

    angular.module('app').$safeitemname$('$itemname$',
        ['$scope', $itemname$]);

    function $itemname$($scope, Service) {
        $scope.service = Service;
    }
})();