(function () {
    'use strict';
	
    angular.module('app').$safeitemname$('$itemname$', ['$location', $itemname$]);

    function $itemname$($location) {
        var self = {};
		

        return self;
    }
})();