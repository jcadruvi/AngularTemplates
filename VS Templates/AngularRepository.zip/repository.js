﻿(function () {
    'use strict';

    angular.module('app').factory('$itemname$', ['dataManager', $itemname$]);

    function $itemname$(dataManager) {
        var self = {};


        return self;
    }
})();