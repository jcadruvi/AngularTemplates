(function () {
    'use strict';

    // Create the module and define its dependencies.
    var $itemname$ = angular.module('$itemname$', [
        // Angular modules 
        //'ngRoute'           // routing
    ]);

    $safeitemname$.config(['$locationProvider', '$routeProvider',
      function ($locationProvider, $routeProvider) {
          $locationProvider.hashPrefix('!');
          /*$routeProvider.
            when('/', {
                templateUrl:  ''
            });*/
      }]);

    // Execute bootstrapping code and any dependencies.
    $safeitemname$.run(['$q', '$rootScope',
        function ($q, $rootScope) {

        }]);

})();