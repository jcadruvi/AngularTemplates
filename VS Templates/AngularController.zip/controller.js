(function () {
    'use strict';

    angular.module('app').$safeitemname$('$itemname$',
        ['$scope', 'Service', $itemname$]);

    function $itemname$($scope, Service) {
        $scope.service = Service;
    }
})();