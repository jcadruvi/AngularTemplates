﻿(function () {
    'use strict';

    angular.module('app').factory('$itemname$', ['Repository', $itemname$]);

    function $itemname$(Repository) {
        var self = {};


        return self;
    }
})();